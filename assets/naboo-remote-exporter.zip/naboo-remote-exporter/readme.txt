# Naboo Remote Exporter

This is a companion plugin for the Naboo Database WordPress plugin.

## Installation

1. Upload the `naboo-remote-exporter` folder to the `/wp-content/plugins/` directory of the **Origin** WordPress site (the site where the drafts are currently located).
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Navigate to **Settings > Naboo Exporter** to view or configure your secure API Token.

## Usage

1. Copy the **API Token** from the settings page.
2. Go to your **Destination** site where Naboo Database is installed.
3. Access the **Naboo Database > Batch AI** page.
4. Use the **Import Remote Drafts** feature by entering the origin site URL (e.g., `https://originsite.com`) and pasting the API Token.
5. Click **Fetch & Import** to securely pull drafts across to the new site as `naboo_raw_draft` posts.
