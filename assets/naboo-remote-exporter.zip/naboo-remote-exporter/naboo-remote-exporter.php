<?php
/**
 * Plugin Name: Naboo Remote Exporter
 * Description: An API endpoint to allow the Naboo Database plugin to securely pull drafts from this site. Also includes a manual file export for offline transfer.
 * Version: 2.0.0
 * Author: Arab Psychology
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ─────────────────────────────────────────────
// TEMPLATE_REDIRECT BASED API (no REST API)
// ─────────────────────────────────────────────
add_action( 'template_redirect', 'naboo_remote_exporter_handle_request' );
function naboo_remote_exporter_handle_request() {
    if ( ! isset( $_GET['naboo_export'] ) ) {
        return;
    }

    $export_action = sanitize_text_field( $_GET['naboo_export'] );
    
    $token = get_option( 'naboo_remote_exporter_token' );
    if ( empty( $token ) ) {
        wp_send_json_error( array( 'message' => 'The API token has not been configured on the origin site.' ), 401 );
    }

    $provided_token = isset( $_SERVER['HTTP_X_NABOO_TOKEN'] ) ? sanitize_text_field( $_SERVER['HTTP_X_NABOO_TOKEN'] ) : '';
    if ( empty( $provided_token ) && isset( $_GET['token'] ) ) {
        $provided_token = sanitize_text_field( $_GET['token'] );
    }

    if ( $provided_token !== $token ) {
        wp_send_json_error( array( 'message' => 'Invalid token.' ), 401 );
    }

    if ( $export_action === 'info' ) {
        $post_types = get_post_types( array( 'public' => true ), 'objects' );
        $types_list = array();
        foreach ( $post_types as $pt ) {
            $types_list[] = array( 'name' => $pt->name, 'label' => $pt->label );
        }
        $post_statuses = get_post_stati( array(), 'objects' );
        $statuses_list = array();
        foreach ( $post_statuses as $status ) {
            $statuses_list[] = array( 'name' => $status->name, 'label' => $status->label );
        }
        wp_send_json( array( 'success' => true, 'types' => $types_list, 'statuses' => $statuses_list ) );
        exit;
    }

    if ( $export_action === 'drafts' ) {
        $post_type = isset( $_GET['post_type'] ) ? sanitize_text_field( $_GET['post_type'] ) : 'post';
        if ( isset( $_GET['post_status'] ) ) {
            $post_status = is_array( $_GET['post_status'] )
                ? array_map( 'sanitize_text_field', wp_unslash( $_GET['post_status'] ) )
                : sanitize_text_field( $_GET['post_status'] );
        } else {
            $post_status = array( 'draft', 'pending' );
        }
        $paged    = isset( $_GET['page'] ) ? absint( $_GET['page'] ) : 1;
        $per_page = isset( $_GET['per_page'] ) ? absint( $_GET['per_page'] ) : 100;
        if ( $per_page > 500 ) $per_page = 500;

        $query = new WP_Query( array(
            'post_type'              => $post_type,
            'post_status'            => $post_status,
            'posts_per_page'         => $per_page,
            'paged'                  => $paged,
            'orderby'                => 'date',
            'order'                  => 'ASC',
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ) );

        $posts = array();
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                $posts[] = array(
                    'id'      => get_the_ID(),
                    'title'   => get_the_title(),
                    'content' => get_the_content(),
                    'excerpt' => get_the_excerpt(),
                    'date'    => get_the_date( 'c' ),
                );
            }
        }
        wp_reset_postdata();

        wp_send_json( array(
            'success'      => true,
            'count'        => count( $posts ),
            'total_pages'  => 'Unknown',
            'current_page' => $paged,
            'data'         => $posts,
        ) );
        exit;
    }

    wp_send_json_error( array( 'message' => 'Invalid action specified.' ), 400 );
}


// ─────────────────────────────────────────────
// ADMIN MENU & SETTINGS PAGE
// ─────────────────────────────────────────────
add_action( 'admin_menu', 'naboo_remote_exporter_menu' );
function naboo_remote_exporter_menu() {
    add_options_page(
        'Naboo Remote Exporter',
        'Naboo Exporter',
        'manage_options',
        'naboo-remote-exporter',
        'naboo_remote_exporter_settings_page'
    );
}

function naboo_remote_exporter_settings_page() {
    if ( isset( $_POST['naboo_remote_token'] ) && current_user_can( 'manage_options' ) && check_admin_referer( 'naboo_remote_save_token' ) ) {
        update_option( 'naboo_remote_exporter_token', sanitize_text_field( $_POST['naboo_remote_token'] ) );
        echo '<div class="notice notice-success is-dismissible"><p>Token saved.</p></div>';
    }

    $token = get_option( 'naboo_remote_exporter_token', wp_generate_password( 24, false ) );
    if ( ! get_option( 'naboo_remote_exporter_token' ) ) {
        update_option( 'naboo_remote_exporter_token', $token );
    }

    // Collect post types / statuses for export panel
    $all_post_types = get_post_types( array(), 'objects' );
    $all_statuses   = get_post_stati( array(), 'objects' );
    ?>
    <div class="wrap">
        <h1>Naboo Remote Exporter</h1>

        <h2>⚙️ API Settings</h2>
        <form method="post" action="">
            <?php wp_nonce_field( 'naboo_remote_save_token' ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">API Token</th>
                    <td>
                        <input type="text" name="naboo_remote_token" value="<?php echo esc_attr( $token ); ?>" style="width:100%;max-width:420px;" />
                        <p class="description">Copy this token and paste it into the Naboo Database plugin on the destination site.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( 'Save Token' ); ?>
        </form>

        <hr>

        <h2>📦 Generate Export ZIPs</h2>
        <p>If you have thousands of posts, direct export might time out. This tool creates chunked <strong>.zip</strong> files (1000 posts each). You can then paste their URLs into the destination site to import them automatically.</p>

        <table class="form-table">
            <tr>
                <th scope="row"><label for="naboo-export-type">Post Type</label></th>
                <td>
                    <select id="naboo-export-type" style="min-width:220px;">
                        <?php foreach ( $all_post_types as $pt ) : ?>
                            <option value="<?php echo esc_attr( $pt->name ); ?>"><?php echo esc_html( $pt->label . ' (' . $pt->name . ')' ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="naboo-export-status">Post Status</label></th>
                <td>
                    <select id="naboo-export-status" style="min-width:220px;">
                        <option value="any">Any</option>
                        <?php foreach ( $all_statuses as $status ) : ?>
                            <option value="<?php echo esc_attr( $status->name ); ?>"><?php echo esc_html( $status->label . ' (' . $status->name . ')' ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
        </table>

        <p>
            <button id="naboo-export-generate-btn" class="button button-primary" style="font-size:15px;height:38px;padding:0 20px;">⚙️ Generate Chunked ZIPs</button>
            <span id="naboo-export-status-msg" style="margin-left:12px;display:none;color:#777;"></span>
        </p>

        <div id="naboo-export-results" style="display:none; margin-top:20px; background:#fff; padding:15px; border:1px solid #ccc; max-width:600px;">
            <p style="margin-top:0;"><strong>Generated Files:</strong> <span style="font-size:12px;color:#666;">(Copy these links to the destination site)</span></p>
            <ul id="naboo-export-links" style="margin-bottom:0;"></ul>
        </div>
    </div>

    <script>
    (function($) {
        $('#naboo-export-generate-btn').on('click', function(e) {
            e.preventDefault();
            var postType = $('#naboo-export-type').val();
            var status   = $('#naboo-export-status').val();
            var $btn     = $(this);
            var $msg     = $('#naboo-export-status-msg');
            var $results = $('#naboo-export-results');
            var $links   = $('#naboo-export-links');

            $btn.prop('disabled', true).text('Generating...');
            $msg.show().text('Starting export...');
            $results.show();
            $links.empty();

            function fetchChunk(page) {
                $msg.text('Generating Part ' + page + ' (1000 posts per chunk)...');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'naboo_export_generate_chunk',
                        nonce:  '<?php echo esc_js( wp_create_nonce( 'naboo_export_nonce' ) ); ?>',
                        post_type:   postType,
                        post_status: status,
                        page:        page
                    },
                    success: function(res) {
                        if (res.success) {
                            var html = '<li>✅ Part ' + page + ': <input type="text" value="' + res.data.url + '" readonly style="width:70%; font-size:12px; padding:3px;" onclick="this.select();"></li>';
                            $links.append(html);

                            if (res.data.has_more) {
                                fetchChunk(page + 1);
                            } else {
                                $btn.prop('disabled', false).text('⚙️ Generate Chunked ZIPs');
                                $msg.text('🎉 All chunks generated!');
                            }
                        } else {
                            $btn.prop('disabled', false).text('⚙️ Generate Chunked ZIPs');
                            if (res.data.message === 'No posts found.') {
                                if (page === 1) {
                                    $msg.text('❌ No posts found matching criteria.');
                                } else {
                                    $msg.text('🎉 All chunks generated!');
                                }
                            } else {
                                $msg.text('❌ Error: ' + res.data.message);
                            }
                        }
                    },
                    error: function() {
                        $btn.prop('disabled', false).text('⚙️ Generate Chunked ZIPs');
                        $msg.text('❌ Server error or timeout. Try again.');
                    }
                });
            }

            fetchChunk(1);
        });
    })(jQuery);
    </script>
    <?php
}

// ─────────────────────────────────────────────
// AJAX HANDLER — GENERATE CHUNKED ZIP
// ─────────────────────────────────────────────
add_action( 'wp_ajax_naboo_export_generate_chunk', 'naboo_ajax_export_generate_chunk' );
function naboo_ajax_export_generate_chunk() {
    check_ajax_referer( 'naboo_export_nonce', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( array( 'message' => 'Permission denied.' ) );
    }

    // Attempt to raise limits for large blocks
    @set_time_limit( 300 );
    @ini_set( 'memory_limit', '512M' );

    $post_type   = sanitize_text_field( $_POST['post_type'] ?? 'post' );
    $post_status = sanitize_text_field( $_POST['post_status'] ?? 'any' );
    $page        = absint( $_POST['page'] ?? 1 );
    $per_page    = 1000;

    $args = array(
        'post_type'              => $post_type,
        'post_status'            => $post_status === 'any' ? 'any' : $post_status,
        'posts_per_page'         => $per_page,
        'paged'                  => $page,
        'orderby'                => 'ID',
        'order'                  => 'ASC',
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    );

    $query = new WP_Query( $args );
    $posts = array();

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $posts[] = array(
                'id'      => get_the_ID(),
                'title'   => get_the_title(),
                'content' => get_the_content(),
                'excerpt' => get_the_excerpt(),
                'date'    => get_the_date( 'c' ),
            );
        }
    }
    wp_reset_postdata();

    if ( empty( $posts ) ) {
        wp_send_json_error( array( 'message' => 'No posts found.' ) );
    }

    // Create export folder
    $upload_dir = wp_upload_dir();
    $export_dir = $upload_dir['basedir'] . '/naboo-exports';
    $export_url = $upload_dir['baseurl'] . '/naboo-exports';

    if ( ! file_exists( $export_dir ) ) {
        wp_mkdir_p( $export_dir );
    }
    // Prevent directory listing
    if ( ! file_exists( $export_dir . '/index.php' ) ) {
        file_put_contents( $export_dir . '/index.php', '<?php // silence' );
    }

    $token = wp_generate_password(8, false);
    $filename = "export-{$post_type}-{$post_status}-p{$page}-{$token}";
    $json_path = $export_dir . '/' . $filename . '.json';
    $zip_path  = $export_dir . '/' . $filename . '.zip';
    $zip_url   = $export_url . '/' . $filename . '.zip';

    // 1. Save JSON
    file_put_contents( $json_path, wp_json_encode( $posts ) );

    // 2. Add to ZIP
    if ( class_exists( 'ZipArchive' ) ) {
        $zip = new ZipArchive();
        if ( $zip->open( $zip_path, ZipArchive::CREATE | ZipArchive::OVERWRITE ) === true ) {
            $zip->addFile( $json_path, 'data.json' );
            $zip->close();
        } else {
            @unlink( $json_path );
            wp_send_json_error( array( 'message' => 'Failed to create ZIP archive.' ) );
        }
    } else {
        @unlink( $json_path );
        wp_send_json_error( array( 'message' => 'ZipArchive PHP extension is missing.' ) );
    }

    // Cleanup JSON
    @unlink( $json_path );

    wp_send_json_success( array(
        'count'    => count( $posts ),
        'url'      => $zip_url,
        'has_more' => count( $posts ) === $per_page
    ) );
}
